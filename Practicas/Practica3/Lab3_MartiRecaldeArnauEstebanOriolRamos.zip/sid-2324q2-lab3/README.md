
El codi s'executa amb Python3

S'han d'instalar els seguents requirements:
    pip install -r requirements.txt

El main_1.5.py es per les preguntes 1 i 5.
El main_1.4.py es per la pregunta 4.
El main_1.6.py es per la pregunta 6.
El notebook baseline.ipynb per la resta (2,3).

Podem parametritzar a exp_config en el main dels codis.